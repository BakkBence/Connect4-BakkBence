public class ConnectFour {
    private char[][] grid;
    private int numRows = 6;
    public static final int numCols = 7;
    public static final int numRowsStatic = 6;
    private char activePlayer;

    public ConnectFour() {
        grid = new char[numRowsStatic][numCols];
        for (int i = 0; i < numRowsStatic; i++) {
            for (int j = 0; j < numCols; j++) {
                grid[i][j] = ' ';
            }
        }
        activePlayer = 'X';
    }


    public char getActivePlayer() {
        return activePlayer;
    }


    public void setActivePlayer(char player) {
        activePlayer = player;
    }


    public char getCell(int row, int col) {
        return grid[row][col];
    }


    public void setCell(int row, int col, char value) {
        grid[row][col] = value;
    }

    public void displayBoard() {
        for (int i = 0; i < numRowsStatic; i++) {
            for (int j = 0; j < numCols; j++) {
                System.out.print("| " + grid[i][j] + " ");
            }
            System.out.println("|");
            System.out.println("-----------------------------");
        }
    }

    public boolean placeToken(int col, char player) {
        if (!isMoveValid(col)) {
            return false;
        }
        for (int i = numRowsStatic - 1; i >= 0; i--) {
            if (grid[i][col] == ' ') {
                grid[i][col] = player;
                return true;
            }
        }
        return false;
    }

    public boolean checkVictory(char player) {
        return checkHorizontal(player) || checkVertical(player) || checkDiagonal(player);
    }

    public boolean isGridFull() {
        for (int j = 0; j < numCols; j++) {
            if (grid[0][j] == ' ') {
                return false;
            }
        }
        return true;
    }

    public boolean isMoveValid(int col) {
        if (col < 0 || col >= numCols) {
            return false;
        }
        return grid[0][col] == ' ';
    }

    private boolean checkHorizontal(char player) {
        for (int i = 0; i < numRowsStatic; i++) {
            for (int j = 0; j < numCols - 3; j++) {
                if (grid[i][j] == player && grid[i][j + 1] == player &&
                        grid[i][j + 2] == player && grid[i][j + 3] == player) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean checkVertical(char player) {
        for (int j = 0; j < numCols; j++) {
            for (int i = 0; i < numRowsStatic - 3; i++) {
                if (grid[i][j] == player && grid[i + 1][j] == player &&
                        grid[i + 2][j] == player && grid[i + 3][j] == player) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean checkDiagonal(char player) {
        for (int i = 0; i < numRowsStatic - 3; i++) {
            for (int j = 0; j < numCols - 3; j++) {
                if (grid[i][j] == player && grid[i + 1][j + 1] == player &&
                        grid[i + 2][j + 2] == player && grid[i + 3][j + 3] == player) {
                    return true;
                }
            }
        }
        for (int i = 3; i < numRowsStatic; i++) {
            for (int j = 0; j < numCols - 3; j++) {
                if (grid[i][j] == player && grid[i - 1][j + 1] == player &&
                        grid[i - 2][j + 2] == player && grid[i - 3][j + 3] == player) {
                    return true;
                }
            }
        }
        return false;
    }
}