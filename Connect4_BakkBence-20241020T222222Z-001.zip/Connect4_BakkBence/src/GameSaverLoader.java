import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;

public class GameSaverLoader {


    public static void saveGame(ConnectFour game, String filename) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();


            Element rootElement = doc.createElement("ConnectFourGame");
            doc.appendChild(rootElement);


            Element activePlayer = doc.createElement("ActivePlayer");
            activePlayer.appendChild(doc.createTextNode(String.valueOf(game.getActivePlayer())));
            rootElement.appendChild(activePlayer);


            Element boardElement = doc.createElement("Grid");
            for (int i = 0; i < ConnectFour.numRowsStatic; i++) {
                Element row = doc.createElement("Row");
                for (int j = 0; j < ConnectFour.numCols; j++) {
                    Element cell = doc.createElement("Cell");
                    cell.appendChild(doc.createTextNode(String.valueOf(game.getCell(i, j))));
                    row.appendChild(cell);
                }
                boardElement.appendChild(row);
            }
            rootElement.appendChild(boardElement);


            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filename));
            transformer.transform(source, result);

            System.out.println("A játékállás sikeresen elmentve: " + filename);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void loadGame(ConnectFour game, String filename) {
        try {
            File file = new File(filename);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(file);

            doc.getDocumentElement().normalize();

            String activePlayer = doc.getElementsByTagName("ActivePlayer").item(0).getTextContent();
            game.setActivePlayer(activePlayer.charAt(0));


            for (int i = 0; i < ConnectFour.numRowsStatic; i++) {
                for (int j = 0; j < ConnectFour.numCols; j++) {
                    String cellValue = doc.getElementsByTagName("Row").item(i).getChildNodes().item(j).getTextContent();
                    game.setCell(i, j, cellValue.charAt(0));
                }
            }

            System.out.println("A játékállás sikeresen betöltve: " + filename);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}